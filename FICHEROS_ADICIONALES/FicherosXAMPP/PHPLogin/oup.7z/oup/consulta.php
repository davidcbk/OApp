<?php
include('funciones.php'); 
$DNI=$_GET['DNI'];
if ($resultset = getSQLResultSet("SELECT contrasena FROM `usuarios` WHERE DNI='$DNI'")) {
	
    	while ($row = $resultset->fetch_array(MYSQLI_NUM)) {
    	echo json_encode($row);
		
    	
    	}
    	
   }
   
?>
